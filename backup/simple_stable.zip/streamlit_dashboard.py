"""
Streamlit Dashboard for Violence Detection System
Real-time monitoring with statistics and alerts
"""

import streamlit as st
import cv2
import numpy as np
import tensorflow as tf
import mediapipe as mp
import time
from collections import deque
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime
import threading

# Page config
st.set_page_config(
    page_title="Violence Detection Dashboard",
    page_icon="🚨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# LOAD MODELS
# ============================================================================

@st.cache_resource
def load_models():
    """Load all models (cached)"""
    try:
        # Violence detection
        cnn = tf.lite.Interpreter(model_path='mobilenet_feature_extractor.tflite')
        cnn.allocate_tensors()
        
        lstm = tf.lite.Interpreter(model_path='violence_detection_lstm.tflite')
        lstm.allocate_tensors()
        
        # Gender classification
        try:
            gender = tf.lite.Interpreter(model_path='gender_classification.tflite')
            gender.allocate_tensors()
            gender_enabled = True
        except:
            gender = None
            gender_enabled = False
        
        # MediaPipe
        pose = mp.solutions.pose.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
            model_complexity=1
        )
        
        # Face detector
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        
        return {
            'cnn': cnn,
            'lstm': lstm,
            'gender': gender,
            'gender_enabled': gender_enabled,
            'pose': pose,
            'face_cascade': face_cascade
        }
    except Exception as e:
        st.error(f"Error loading models: {e}")
        return None

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def detect_aggressive_pose(landmarks):
    """Detect aggressive postures"""
    if not landmarks:
        return 0.0, []
    
    score = 0.0
    reasons = []
    
    try:
        mp_pose = mp.solutions.pose
        left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
        left_wrist = landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value]
        right_wrist = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value]
        
        if left_wrist.y < left_shoulder.y or right_wrist.y < right_shoulder.y:
            score += 0.4
            reasons.append("Raised arms")
        
        if abs(left_wrist.x - left_shoulder.x) > 0.3 or abs(right_wrist.x - right_shoulder.x) > 0.3:
            score += 0.3
            reasons.append("Extended arms")
        
    except:
        pass
    
    return min(score, 1.0), reasons

def detect_gender(frame, face_cascade, gender_model, gender_enabled):
    """Detect faces and classify gender"""
    if not gender_enabled:
        return 0, 0, 0
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    
    male_count = 0
    female_count = 0
    
    for (x, y, w, h) in faces:
        try:
            face = frame[y:y+h, x:x+w]
            face_resized = cv2.resize(face, (128, 128))
            face_rgb = cv2.cvtColor(face_resized, cv2.COLOR_BGR2RGB)
            face_normalized = np.expand_dims(face_rgb / 255.0, axis=0).astype(np.float32)
            
            gender_input = gender_model.get_input_details()
            gender_output = gender_model.get_output_details()
            
            gender_model.set_tensor(gender_input[0]['index'], face_normalized)
            gender_model.invoke()
            gender_pred = gender_model.get_tensor(gender_output[0]['index'])[0, 0]
            
            if gender_pred > 0.5:
                female_count += 1
                label = "F"
                color = (255, 0, 255)
            else:
                male_count += 1
                label = "M"
                color = (255, 0, 0)
            
            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(frame, label, (x, y-10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        except:
            pass
    
    return male_count, female_count, len(faces)

# ============================================================================
# MAIN APP
# ============================================================================

def main():
    # Title
    st.title("🚨 Violence Detection Dashboard")
    st.markdown("Real-time monitoring with AI-powered violence detection")
    
    # Sidebar
    st.sidebar.header("⚙️ Settings")
    
    violence_threshold = st.sidebar.slider(
        "Violence Threshold",
        min_value=0.0,
        max_value=1.0,
        value=0.7,
        step=0.05,
        help="Higher = fewer false positives"
    )
    
    frame_skip = st.sidebar.slider(
        "Frame Skip",
        min_value=1,
        max_value=5,
        value=2,
        help="Process every Nth frame"
    )
    
    show_skeleton = st.sidebar.checkbox("Show Skeleton", value=True)
    show_gender = st.sidebar.checkbox("Show Gender Detection", value=True)
    
    # Load models
    models = load_models()
    if models is None:
        st.error("Failed to load models. Please check model files.")
        return
    
    # Layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📹 Live Feed")
        video_placeholder = st.empty()
    
    with col2:
        st.subheader("📊 Statistics")
        stats_placeholder = st.empty()
        
        st.subheader("🚨 Recent Alerts")
        alerts_placeholder = st.empty()
        
        st.subheader("📈 Violence Score")
        chart_placeholder = st.empty()
    
    # Control buttons
    col_btn1, col_btn2, col_btn3 = st.columns(3)
    
    with col_btn1:
        start_button = st.button("▶️ Start", use_container_width=True)
    
    with col_btn2:
        stop_button = st.button("⏹️ Stop", use_container_width=True)
    
    with col_btn3:
        reset_button = st.button("🔄 Reset Stats", use_container_width=True)
    
    # Initialize session state
    if 'running' not in st.session_state:
        st.session_state.running = False
    if 'stats' not in st.session_state:
        st.session_state.stats = {
            'violence_count': 0,
            'weapon_count': 0,
            'male_total': 0,
            'female_total': 0,
            'session_start': None,
            'alerts': [],
            'violence_scores': []
        }
    
    if start_button:
        st.session_state.running = True
        st.session_state.stats['session_start'] = time.time()
    
    if stop_button:
        st.session_state.running = False
    
    if reset_button:
        st.session_state.stats = {
            'violence_count': 0,
            'weapon_count': 0,
            'male_total': 0,
            'female_total': 0,
            'session_start': time.time(),
            'alerts': [],
            'violence_scores': []
        }
    
    # Main loop
    if st.session_state.running:
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            st.error("Could not open webcam")
            return
        
        # Buffers
        SEQ_LENGTH = 30
        sequence_buffer = np.zeros((1, SEQ_LENGTH, 1280), dtype=np.float32)
        prediction_history = deque(maxlen=5)
        gender_history = deque(maxlen=30)
        pose_history = deque(maxlen=10)
        
        frame_count = 0
        
        while st.session_state.running:
            ret, frame = cap.read()
            if not ret:
                break
            
            display_frame = frame.copy()
            h, w = display_frame.shape[:2]
            
            # MediaPipe pose
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            pose_results = models['pose'].process(rgb_frame)
            
            pose_score = 0.0
            pose_reasons = []
            
            if pose_results.pose_landmarks:
                if show_skeleton:
                    mp.solutions.drawing_utils.draw_landmarks(
                        display_frame,
                        pose_results.pose_landmarks,
                        mp.solutions.pose.POSE_CONNECTIONS
                    )
                
                landmarks = pose_results.pose_landmarks.landmark
                pose_history.append(landmarks)
                pose_score, pose_reasons = detect_aggressive_pose(landmarks)
            else:
                pose_history.append(None)
            
            # Process frame
            if frame_count % frame_skip == 0:
                # Violence detection
                input_frame = cv2.resize(frame, (128, 128))
                input_frame = cv2.cvtColor(input_frame, cv2.COLOR_BGR2RGB)
                input_frame = np.expand_dims(input_frame, axis=0).astype(np.float32)
                input_frame = (input_frame / 127.5) - 1.0
                
                cnn_input = models['cnn'].get_input_details()
                cnn_output = models['cnn'].get_output_details()
                
                models['cnn'].set_tensor(cnn_input[0]['index'], input_frame)
                models['cnn'].invoke()
                feature_vector = models['cnn'].get_tensor(cnn_output[0]['index'])
                
                sequence_buffer = np.roll(sequence_buffer, shift=-1, axis=1)
                sequence_buffer[0, -1, :] = feature_vector[0, :]
                
                # Gender detection
                if show_gender and models['gender_enabled']:
                    male_count, female_count, total_faces = detect_gender(
                        display_frame,
                        models['face_cascade'],
                        models['gender'],
                        models['gender_enabled']
                    )
                    gender_history.append((male_count, female_count, total_faces))
                    st.session_state.stats['male_total'] += male_count
                    st.session_state.stats['female_total'] += female_count
                
                # LSTM classification
                if frame_count >= SEQ_LENGTH * frame_skip:
                    lstm_input = models['lstm'].get_input_details()
                    lstm_output = models['lstm'].get_output_details()
                    
                    models['lstm'].set_tensor(lstm_input[0]['index'], sequence_buffer)
                    models['lstm'].invoke()
                    lstm_pred = models['lstm'].get_tensor(lstm_output[0]['index'])[0, 0]
                    
                    # Combined score
                    combined_score = (lstm_pred * 0.7) + (pose_score * 0.3)
                    combined_score = np.clip(combined_score, 0, 1)
                    
                    prediction_history.append(combined_score)
                    smoothed = np.mean(prediction_history)
                    
                    # Store for chart
                    st.session_state.stats['violence_scores'].append(smoothed)
                    if len(st.session_state.stats['violence_scores']) > 100:
                        st.session_state.stats['violence_scores'].pop(0)
                    
                    # Check violence
                    recent_high = sum(1 for p in prediction_history if p > violence_threshold)
                    is_violence = smoothed > violence_threshold and recent_high >= 3
                    
                    if is_violence:
                        st.session_state.stats['violence_count'] += 1
                        alert_msg = f"{datetime.now().strftime('%H:%M:%S')} - Violence detected ({smoothed:.2f})"
                        if pose_reasons:
                            alert_msg += f" - {', '.join(pose_reasons)}"
                        st.session_state.stats['alerts'].insert(0, alert_msg)
                        if len(st.session_state.stats['alerts']) > 10:
                            st.session_state.stats['alerts'].pop()
                        
                        v_color = (0, 0, 255)
                        cv2.rectangle(display_frame, (0, 0), (w, h), v_color, 10)
                        cv2.putText(display_frame, "VIOLENCE DETECTED", (10, 50),
                                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, v_color, 3)
                    else:
                        v_color = (0, 255, 0)
                        cv2.putText(display_frame, "NORMAL", (10, 50),
                                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, v_color, 3)
                    
                    # Display score
                    cv2.putText(display_frame, f"Score: {smoothed:.2f}", (10, 90),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            
            frame_count += 1
            
            # Display video
            video_placeholder.image(display_frame, channels="BGR", use_column_width=True)
            
            # Update stats
            session_duration = int(time.time() - st.session_state.stats['session_start'])
            
            stats_data = {
                "Metric": ["Session Duration", "Violence Alerts", "Weapon Detections", "Male Detections", "Female Detections"],
                "Value": [
                    f"{session_duration}s",
                    st.session_state.stats['violence_count'],
                    st.session_state.stats['weapon_count'],
                    st.session_state.stats['male_total'],
                    st.session_state.stats['female_total']
                ]
            }
            stats_placeholder.dataframe(pd.DataFrame(stats_data), use_container_width=True, hide_index=True)
            
            # Update alerts
            if st.session_state.stats['alerts']:
                alerts_text = "\n".join(st.session_state.stats['alerts'][:5])
                alerts_placeholder.text_area("", alerts_text, height=150, disabled=True)
            
            # Update chart
            if len(st.session_state.stats['violence_scores']) > 0:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    y=st.session_state.stats['violence_scores'],
                    mode='lines',
                    name='Violence Score',
                    line=dict(color='red', width=2)
                ))
                fig.add_hline(y=violence_threshold, line_dash="dash", line_color="yellow",
                             annotation_text="Threshold")
                fig.update_layout(
                    height=200,
                    margin=dict(l=0, r=0, t=0, b=0),
                    xaxis_title="Frame",
                    yaxis_title="Score",
                    yaxis_range=[0, 1]
                )
                chart_placeholder.plotly_chart(fig, use_container_width=True)
            
            time.sleep(0.01)
        
        cap.release()
    
    else:
        st.info("Click 'Start' to begin monitoring")

if __name__ == "__main__":
    main()
