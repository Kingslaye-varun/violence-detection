# Enhanced Violence Detection System

## 🎯 Features

### ✅ Enhanced Detection (enhanced_detection.py)
- **Continuous MediaPipe Pose Analysis** - Always shows skeleton
- **Weapon Detection** - Detects sharp objects (knife, scissors)
- **Gender Classification** - Male/Female ratio tracking
- **Real-time Statistics** - Session stats displayed at end
- **Combined AI Scoring** - LSTM + Pose + Velocity

### ✅ Streamlit Dashboard (streamlit_dashboard.py)
- **Web-based Interface** - Professional dashboard
- **Real-time Monitoring** - Live video feed
- **Statistics Panel** - Violence alerts, gender ratio
- **Alert History** - Recent detections
- **Live Charts** - Violence score over time
- **Adjustable Settings** - Threshold, frame skip

## 📦 Installation

```bash
pip install -r requirements.txt
```

## 🚀 Usage

### Option 1: Enhanced Detection (OpenCV)

```bash
python enhanced_detection.py
```

**Features:**
- Continuous MediaPipe skeleton overlay
- Weapon detection alerts
- Gender classification with face boxes
- Session statistics at end
- Press 'q' or ESC to quit

**What You'll See:**
- Green border = Normal
- Red border = Violence detected
- Blue boxes = Male faces
- Pink boxes = Female faces
- Skeleton overlay = Body pose
- Weapon alerts = Sharp objects detected

### Option 2: Streamlit Dashboard (Web Interface)

```bash
streamlit run streamlit_dashboard.py
```

**Features:**
- Professional web interface
- Real-time video feed
- Live statistics panel
- Alert history
- Violence score chart
- Adjustable settings

**Access:**
- Opens automatically in browser
- Usually at: http://localhost:8501

## 📊 What's New

### Enhanced Detection Improvements:

1. **Continuous MediaPipe**
   - Skeleton always visible
   - Real-time pose analysis
   - Aggressive posture detection

2. **Weapon Detection**
   - Detects sharp objects
   - Alerts on screen
   - Adds to violence score

3. **Better Gender Display**
   - Face boxes with labels (M/F)
   - Real-time counts
   - Session totals at end

4. **Session Statistics**
   - Total violence alerts
   - Total weapon detections
   - Male/Female detection counts
   - Session duration

### Streamlit Dashboard Features:

1. **Web Interface**
   - Professional design
   - Easy to use
   - No OpenCV window

2. **Live Statistics**
   - Real-time updates
   - Violence count
   - Gender ratio
   - Session duration

3. **Alert History**
   - Last 10 alerts
   - Timestamps
   - Reasons (pose, weapon)

4. **Live Chart**
   - Violence score over time
   - Threshold line
   - Last 100 frames

5. **Settings**
   - Adjustable threshold
   - Frame skip control
   - Toggle skeleton
   - Toggle gender

## 🎨 Display Comparison

### Enhanced Detection (OpenCV):
```
┌═══════════════════════════════════════┐
║ ⚠️  VIOLENCE DETECTED                ║ ← Red border
║ AI: 0.82 | Pose: 0.65 | Combined: 0.78║
║ Pose: Raised arms, Extended arms     ║
║ ⚠️  Sharp object detected            ║
║ Velocity: 45.2                        ║
╠═══════════════════════════════════════╣
║                                       ║
║     [Webcam with skeleton]            ║
║     [Face boxes: M/F labels]          ║
║                                       ║
╠═══════════════════════════════════════╣
║ Gender: M:2 F:1 Total:3               ║
║ Avg Ratio: M:67% F:33%                ║
║ Session: 45s | Alerts: 3 | Weapons: 1║
└═══════════════════════════════════════┘
```

### Streamlit Dashboard:
```
┌─────────────────────────────────────────────────────┐
│ 🚨 Violence Detection Dashboard                    │
├──────────────────────┬──────────────────────────────┤
│ 📹 Live Feed         │ 📊 Statistics                │
│                      │ Session Duration: 45s        │
│  [Video with         │ Violence Alerts: 3           │
│   skeleton overlay]  │ Weapon Detections: 1         │
│                      │ Male Detections: 67          │
│                      │ Female Detections: 34        │
│                      ├──────────────────────────────┤
│                      │ 🚨 Recent Alerts             │
│                      │ 14:23:45 - Violence (0.82)   │
│                      │ 14:23:12 - Violence (0.76)   │
│                      ├──────────────────────────────┤
│                      │ 📈 Violence Score            │
│                      │ [Live chart]                 │
├──────────────────────┴──────────────────────────────┤
│ ▶️ Start  ⏹️ Stop  🔄 Reset Stats                  │
└─────────────────────────────────────────────────────┘
```

## ⚙️ Configuration

### Enhanced Detection:
Edit in `enhanced_detection.py`:
```python
VIOLENCE_THRESHOLD = 0.7  # Sensitivity
FRAME_SKIP = 2            # Processing speed
```

### Streamlit Dashboard:
Adjust in sidebar:
- Violence Threshold slider
- Frame Skip slider
- Show Skeleton checkbox
- Show Gender checkbox

## 🔧 Troubleshooting

### Issue: Gender not showing
**Solution:** Make sure `gender_classification.tflite` exists

### Issue: No skeleton visible
**Solution:** Check MediaPipe installation:
```bash
pip install --upgrade mediapipe
```

### Issue: Streamlit not opening
**Solution:** 
```bash
streamlit run streamlit_dashboard.py --server.port 8501
```

### Issue: Low FPS
**Solution:** Increase FRAME_SKIP or use lower resolution

## 📈 Performance

### Enhanced Detection:
- FPS: 20-25 (with skeleton)
- CPU: Medium
- Features: All enabled

### Streamlit Dashboard:
- FPS: 15-20 (web overhead)
- CPU: Medium-High
- Features: All enabled + web interface

## 🎓 How It Works

### Violence Detection:
1. **CNN** extracts features from frames
2. **LSTM** analyzes temporal patterns
3. **MediaPipe** detects aggressive poses
4. **Combined scoring** for final decision

### Weapon Detection:
- Edge detection for sharp objects
- Adds bonus to violence score
- Triggers immediate alert

### Gender Classification:
- Face detection with Haar Cascade
- MobileNetV2 for gender classification
- Real-time counting and ratio

## 📊 Session Statistics

At the end of each session, you'll see:

```
================================================================================
SESSION STATISTICS
================================================================================
Duration: 120 seconds
Total Violence Alerts: 5
Total Weapon Detections: 2

Gender Statistics:
  Total Male detections: 145
  Total Female detections: 78
  Male ratio: 65.0%
  Female ratio: 35.0%
================================================================================
```

## 🚀 Which One to Use?

### Use Enhanced Detection if:
- ✅ You want maximum features
- ✅ You prefer OpenCV window
- ✅ You need weapon detection
- ✅ You want session statistics

### Use Streamlit Dashboard if:
- ✅ You want web interface
- ✅ You need remote monitoring
- ✅ You want live charts
- ✅ You prefer professional UI

## 💡 Tips

1. **Good Lighting** - Helps all detections
2. **Full Body View** - Better pose analysis
3. **Stable Camera** - Reduces false positives
4. **Face Camera** - Better gender detection

## 📞 Summary

Both versions include:
- ✅ Continuous MediaPipe skeleton
- ✅ Weapon detection
- ✅ Gender classification
- ✅ Session statistics
- ✅ Real-time alerts

Choose based on your preference:
- **enhanced_detection.py** - Full-featured OpenCV
- **streamlit_dashboard.py** - Professional web interface

Enjoy! 🎉
